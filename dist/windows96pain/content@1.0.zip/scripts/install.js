var tasks = w96.__debug.processes
for (let i = 0; i < tasks.length; i++) {
    try{tasks[i].terminate();}catch{}
}
